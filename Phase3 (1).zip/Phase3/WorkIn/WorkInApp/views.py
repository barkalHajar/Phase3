from django.views import generic
from django.urls import reverse_lazy
from . import models
from . import forms
#
'''from django.shortcuts import render, redirect
from django.core.validators import validate_email
from django.contrib.auth.models import User
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
#from .filters import OrderFilter
#from django.forms import inlineformset_factory


def loginn(request):

    if request.method == "POST":
        email = request.POST.get('email', None)
        password = request.POST.get('password', None)

        user = User.objects.filter(email=email).first()
        if user:
            auth_user = authenticate(username=user.username, password=password)
            if auth_user:
                login(request, auth_user)
                return redirect('dashboard')
            else:
                print("mot de pass incorrecte")
        else:
            print("User does not exist")

    return render(request, 'WorkInApp_login', {})


def register(request):
    error = False
    message = ""
    if request.method == "POST":
        name = request.POST.get('name', None)
        email = request.POST.get('email', None)
        password = request.POST.get('password', None)
        repassword = request.POST.get('repassword', None)
        # Email
        try:
            validate_email(email)
        except:
            error = True
            message = "Enter un email valide svp!"
        # password
        if error == False:
            if password != repassword:
                error = True
                message = "Les deux mot de passe ne correspondent pas!"
        # Exist
        user = User.objects.filter(Q(email=email) | Q(username=name)).first()
        if user:
            error = True
            message = f"Un utilisateur avec email {email} ou le nom d'utilisateur {name} exist déjà'!"

        # register
        if error == False:
            user = User(
                username=name,
                email=email,
            )
            user.save()

            user.password = password
            user.set_password(user.password)
            user.save()

            return redirect('sing_in')

            # print("=="*5, " NEW POST: ",name,email, password, repassword, "=="*5)

    context = {
        'error': error,
        'message': message
    }
    return render(request, 'WorkInApp_register', context)


@login_required(login_url='login')
def dashboard(request):
    return render(request, 'index.html', {})

'''
def log_out(request):
    logout(request)
    return redirect('login')

from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views import generic

class SignupView(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'registration/signup.html'

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            user_type = request.POST.get('user_type')
            if user_type == 'employeur':
                return redirect('employeur')
            else:
                return redirect('employe')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'registration/login.html')


#
class ContratListView(generic.ListView):
    model = models.Contrat
    form_class = forms.ContratForm


class ContratCreateView(generic.CreateView):
    model = models.Contrat
    form_class = forms.ContratForm


class ContratDetailView(generic.DetailView):
    model = models.Contrat
    form_class = forms.ContratForm
    pk_url_kwarg = "ID_Contrat"


class ContratUpdateView(generic.UpdateView):
    model = models.Contrat
    form_class = forms.ContratForm
    pk_url_kwarg = "ID_Contrat"


class ContratDeleteView(generic.DeleteView):
    model = models.Contrat
    success_url = reverse_lazy("WorkInApp_Contrat_list")


class EmployeurListView(generic.ListView):
    model = models.Employeur
    form_class = forms.EmployeurForm


class EmployeurCreateView(generic.CreateView):
    model = models.Employeur
    form_class = forms.EmployeurForm


class EmployeurDetailView(generic.DetailView):
    model = models.Employeur
    form_class = forms.EmployeurForm
    pk_url_kwarg = "ID_Employeur"


class EmployeurUpdateView(generic.UpdateView):
    model = models.Employeur
    form_class = forms.EmployeurForm
    pk_url_kwarg = "ID_Employeur"


class EmployeurDeleteView(generic.DeleteView):
    model = models.Employeur
    success_url = reverse_lazy("WorkInApp_Employeur_list")


class EmployeeListView(generic.ListView):
    model = models.Employee
    form_class = forms.EmployeeForm


class EmployeeCreateView(generic.CreateView):
    model = models.Employee
    form_class = forms.EmployeeForm


class EmployeeDetailView(generic.DetailView):
    model = models.Employee
    form_class = forms.EmployeeForm
    pk_url_kwarg = "ID_Employee"


class EmployeeUpdateView(generic.UpdateView):
    model = models.Employee
    form_class = forms.EmployeeForm
    pk_url_kwarg = "ID_Employee"


class EmployeeDeleteView(generic.DeleteView):
    model = models.Employee
    success_url = reverse_lazy("WorkInApp_Employee_list")


class FactureListView(generic.ListView):
    model = models.Facture
    form_class = forms.FactureForm


class FactureCreateView(generic.CreateView):
    model = models.Facture
    form_class = forms.FactureForm


class FactureDetailView(generic.DetailView):
    model = models.Facture
    form_class = forms.FactureForm
    pk_url_kwarg = "ID_Facture"


class FactureUpdateView(generic.UpdateView):
    model = models.Facture
    form_class = forms.FactureForm
    pk_url_kwarg = "ID_Facture"


class FactureDeleteView(generic.DeleteView):
    model = models.Facture
    success_url = reverse_lazy("WorkInApp_Facture_list")


class MissionListView(generic.ListView):
    model = models.Mission
    form_class = forms.MissionForm


class MissionCreateView(generic.CreateView):
    model = models.Mission
    form_class = forms.MissionForm


class MissionDetailView(generic.DetailView):
    model = models.Mission
    form_class = forms.MissionForm
    pk_url_kwarg = "ID_Mission"


class MissionUpdateView(generic.UpdateView):
    model = models.Mission
    form_class = forms.MissionForm
    pk_url_kwarg = "ID_Mission"


class MissionDeleteView(generic.DeleteView):
    model = models.Mission
    success_url = reverse_lazy("WorkInApp_Mission_list")

