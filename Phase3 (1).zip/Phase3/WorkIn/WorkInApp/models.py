from django.db import models
from django.urls import reverse
#
'''
from django.contrib.auth.models import AbstractUser

class Employeur1(AbstractUser):
    is_employeur = True


class Employee1(AbstractUser):
    is_employeee = True

#
from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_employeur = models.BooleanField(default=False)
#
 '''

class Contrat(models.Model):

    # Fields
    ID_Contrat = models.AutoField(primary_key=True)
    Statut = models.BooleanField()
    created = models.DateTimeField(auto_now_add=True, editable=False)
    Description = models.TextField(max_length=100)
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    Date_de_creation = models.DateField()

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("WorkInApp_Contrat_detail", args=(self.ID_Contrat,))

    def get_update_url(self):
        return reverse("WorkInApp_Contrat_update", args=(self.ID_Contrat,))



class Employeur(models.Model):

    # Fields
    Raison_social = models.TextField(max_length=100)
    Adresse = models.TextField(max_length=100)
    CA = models.FloatField()
    created = models.DateTimeField(auto_now_add=True, editable=False)
    Denomination_social = models.TextField(max_length=100)
    Email = models.TextField(max_length=100)
    ID_Employeur = models.AutoField(primary_key=True)
    Secteur_d_activite = models.TextField(max_length=100)
    Tel = models.TextField(max_length=100)
    last_updated = models.DateTimeField(auto_now=True, editable=False)

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("WorkInApp_Employeur_detail", args=(self.ID_Employeur,))

    def get_update_url(self):
        return reverse("WorkInApp_Employeur_update", args=(self.ID_Employeur,))



class Employee(models.Model):

    # Fields
    Date_de_naissance = models.DateField()
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    Nom = models.TextField(max_length=100)
    Prenom = models.TextField(max_length=100)
    Email = models.TextField(max_length=100)
    Solde = models.FloatField()
    Adresse = models.TextField(max_length=100)
    Tel = models.TextField(max_length=100)
    ID_Employee = models.AutoField(primary_key=True)
    created = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("WorkInApp_Employee_detail", args=(self.ID_Employee,))

    def get_update_url(self):
        return reverse("WorkInApp_Employee_update", args=(self.ID_Employee,))



class Facture(models.Model):

    # Fields
    created = models.DateTimeField(auto_now_add=True, editable=False)
    ID_Facture = models.AutoField(primary_key=True)
    Quantite = models.FloatField()
    Statut = models.BooleanField()
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    TVA = models.FloatField()
    Montant = models.FloatField()

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("WorkInApp_Facture_detail", args=(self.ID_Facture,))

    def get_update_url(self):
        return reverse("WorkInApp_Facture_update", args=(self.ID_Facture,))



class Mission(models.Model):

    # Fields
    Nbr_employee = models.IntegerField()
    Description = models.TextField(max_length=100)
    Date_de_creation_mission = models.DateField()
    Statut = models.BooleanField()
    Lieu_de_mission = models.TextField(max_length=100)
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    Fin_de_mission = models.DateField()
    Prix_heure = models.FloatField()
    Quantite_heure = models.FloatField()
    Date_de_debut_de_mission = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False)
    contract_support = models.TextField(max_length=100)
    ID_Mission = models.AutoField(primary_key=True)

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("WorkInApp_Mission_detail", args=(self.ID_Mission,))

    def get_update_url(self):
        return reverse("WorkInApp_Mission_update", args=(self.ID_Mission,))

