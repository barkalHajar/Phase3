from django.contrib import admin
from django import forms

from . import models


class ContratAdminForm(forms.ModelForm):

    class Meta:
        model = models.Contrat
        fields = "__all__"


class ContratAdmin(admin.ModelAdmin):
    form = ContratAdminForm
    list_display = [
        "ID_Contrat",
        "Statut",
        "created",
        "Description",
        "last_updated",
        "Date_de_creation",
    ]
    readonly_fields = [
        "ID_Contrat",
        "Statut",
        "created",
        "Description",
        "last_updated",
        "Date_de_creation",
    ]


class EmployeurAdminForm(forms.ModelForm):

    class Meta:
        model = models.Employeur
        fields = "__all__"


class EmployeurAdmin(admin.ModelAdmin):
    form = EmployeurAdminForm
    list_display = [
        "Raison_social",
        "Adresse",
        "CA",
        "created",
        "Denomination_social",
        "Email",
        "ID_Employeur",
        "Secteur_d_activite",
        "Tel",
        "last_updated",
    ]
    readonly_fields = [
        "Raison_social",
        "Adresse",
        "CA",
        "created",
        "Denomination_social",
        "Email",
        "ID_Employeur",
        "Secteur_d_activite",
        "Tel",
        "last_updated",
    ]


class EmployeeAdminForm(forms.ModelForm):

    class Meta:
        model = models.Employee
        fields = "__all__"


class EmployeeAdmin(admin.ModelAdmin):
    form = EmployeeAdminForm
    list_display = [
        "Date_de_naissance",
        "last_updated",
        "Nom",
        "Prenom",
        "Email",
        "Solde",
        "Adresse",
        "Tel",
        "ID_Employee",
        "created",
    ]
    readonly_fields = [
        "Date_de_naissance",
        "last_updated",
        "Nom",
        "Prenom",
        "Email",
        "Solde",
        "Adresse",
        "Tel",
        "ID_Employee",
        "created",
    ]


class FactureAdminForm(forms.ModelForm):

    class Meta:
        model = models.Facture
        fields = "__all__"


class FactureAdmin(admin.ModelAdmin):
    form = FactureAdminForm
    list_display = [
        "created",
        "ID_Facture",
        "Quantite",
        "Statut",
        "last_updated",
        "TVA",
        "Montant",
    ]
    readonly_fields = [
        "created",
        "ID_Facture",
        "Quantite",
        "Statut",
        "last_updated",
        "TVA",
        "Montant",
    ]


class MissionAdminForm(forms.ModelForm):

    class Meta:
        model = models.Mission
        fields = "__all__"


class MissionAdmin(admin.ModelAdmin):
    form = MissionAdminForm
    list_display = [
        "Nbr_employee",
        "Description",
        "Date_de_creation_mission",
        "Statut",
        "Lieu_de_mission",
        "last_updated",
        "Fin_de_mission",
        "Prix_heure",
        "Quantite_heure",
        "Date_de_debut_de_mission",
        "created",
        "contract_support",
        "ID_Mission",
    ]
    readonly_fields = [
        "Nbr_employee",
        "Description",
        "Date_de_creation_mission",
        "Statut",
        "Lieu_de_mission",
        "last_updated",
        "Fin_de_mission",
        "Prix_heure",
        "Quantite_heure",
        "Date_de_debut_de_mission",
        "created",
        "contract_support",
        "ID_Mission",
    ]


admin.site.register(models.Contrat, ContratAdmin)
admin.site.register(models.Employeur, EmployeurAdmin)
admin.site.register(models.Employee, EmployeeAdmin)
admin.site.register(models.Facture, FactureAdmin)
admin.site.register(models.Mission, MissionAdmin)
