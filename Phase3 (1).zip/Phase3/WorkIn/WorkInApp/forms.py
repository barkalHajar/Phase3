from django import forms
from . import models

#
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Employeur
'''
class Employeur1CreationForm(UserCreationForm):
    class Meta:
        model = Employeur1
        fields = ['username', 'email', 'password1', 'password2']

class EmployeCreationForm(UserCreationForm):
    class Meta:
        model = Employe
        fields = ['username', 'email', 'password1', 'password2']

#

'''
class ContratForm(forms.ModelForm):
    class Meta:
        model = models.Contrat
        fields = [
            "Statut",
            "Description",
            "Date_de_creation",
        ]


class EmployeurForm(forms.ModelForm):
    class Meta:
        model = models.Employeur
        fields = [
            "Raison_social",
            "Adresse",
            "CA",
            "Denomination_social",
            "Email",
            "Secteur_d_activite",
            "Tel",
        ]


class EmployeeForm(forms.ModelForm):
    class Meta:
        model = models.Employee
        fields = [
            "Date_de_naissance",
            "Nom",
            "Prenom",
            "Email",
            "Solde",
            "Adresse",
            "Tel",
        ]


class FactureForm(forms.ModelForm):
    class Meta:
        model = models.Facture
        fields = [
            "Quantite",
            "Statut",
            "TVA",
            "Montant",
        ]


class MissionForm(forms.ModelForm):
    class Meta:
        model = models.Mission
        fields = [
            "Nbr_employee",
            "Description",
            "Date_de_creation_mission",
            "Statut",
            "Lieu_de_mission",
            "Fin_de_mission",
            "Prix_heure",
            "Quantite_heure",
            "Date_de_debut_de_mission",
            "contract_support",
        ]
