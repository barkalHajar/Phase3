from django.urls import path, include
from rest_framework import routers

from . import api
from . import views


router = routers.DefaultRouter()
router.register("Contrat", api.ContratViewSet)
router.register("Employeur", api.EmployeurViewSet)
router.register("Employee", api.EmployeeViewSet)
router.register("Facture", api.FactureViewSet)
router.register("Mission", api.MissionViewSet)

#
from django.urls import path, include
from rest_framework import routers
from rest_framework.authtoken.views import obtain_auth_token
from django.contrib.auth import views as auth_views
from django.urls import path
from django.contrib.auth.views import LogoutView
#from .views import CustomLoginView

#

urlpatterns = (
    #
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls')),
    path('api-token-auth/', obtain_auth_token, name='api_token_auth'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('signup/', views.SignupView.as_view(), name='signup'),
    #path('employeur1/', include('employeur1.urls')),
    #path('employe/', include('employe.urls')),
    #path('employe/', views.SignupView.as_view(), name='employe'),
    #path('employeur/', views.SignupView.as_view(), name='employeur'),



    #path('login/', CustomLoginView.as_view(), name='login'),
    #path('logout/', LogoutView.as_view(), name='logout'),
    # ... autres URL de l'application ...


    #
    path("api/v1/", include(router.urls)),
    path("WorkInApp/Contrat/", views.ContratListView.as_view(), name="WorkInApp_Contrat_list"),
    path("WorkInApp/Contrat/create/", views.ContratCreateView.as_view(), name="WorkInApp_Contrat_create"),
    path("WorkInApp/Contrat/detail/<int:ID_Contrat>/", views.ContratDetailView.as_view(), name="WorkInApp_Contrat_detail"),
    path("WorkInApp/Contrat/update/<int:ID_Contrat>/", views.ContratUpdateView.as_view(), name="WorkInApp_Contrat_update"),
    path("WorkInApp/Contrat/delete/<int:ID_Contrat>/", views.ContratDeleteView.as_view(), name="WorkInApp_Contrat_delete"),
    path("WorkInApp/Employeur/", views.EmployeurListView.as_view(), name="WorkInApp_Employeur_list"),
    path("WorkInApp/Employeur/create/", views.EmployeurCreateView.as_view(), name="WorkInApp_Employeur_create"),
    path("WorkInApp/Employeur/detail/<int:ID_Employeur>/", views.EmployeurDetailView.as_view(), name="WorkInApp_Employeur_detail"),
    path("WorkInApp/Employeur/update/<int:ID_Employeur>/", views.EmployeurUpdateView.as_view(), name="WorkInApp_Employeur_update"),
    path("WorkInApp/Employeur/delete/<int:ID_Employeur>/", views.EmployeurDeleteView.as_view(), name="WorkInApp_Employeur_delete"),
    path("WorkInApp/Employee/", views.EmployeeListView.as_view(), name="WorkInApp_Employee_list"),
    path("WorkInApp/Employee/create/", views.EmployeeCreateView.as_view(), name="WorkInApp_Employee_create"),
    path("WorkInApp/Employee/detail/<int:ID_Employee>/", views.EmployeeDetailView.as_view(), name="WorkInApp_Employee_detail"),
    path("WorkInApp/Employee/update/<int:ID_Employee>/", views.EmployeeUpdateView.as_view(), name="WorkInApp_Employee_update"),
    path("WorkInApp/Employee/delete/<int:ID_Employee>/", views.EmployeeDeleteView.as_view(), name="WorkInApp_Employee_delete"),
    path("WorkInApp/Facture/", views.FactureListView.as_view(), name="WorkInApp_Facture_list"),
    path("WorkInApp/Facture/create/", views.FactureCreateView.as_view(), name="WorkInApp_Facture_create"),
    path("WorkInApp/Facture/detail/<int:ID_Facture>/", views.FactureDetailView.as_view(), name="WorkInApp_Facture_detail"),
    path("WorkInApp/Facture/update/<int:ID_Facture>/", views.FactureUpdateView.as_view(), name="WorkInApp_Facture_update"),
    path("WorkInApp/Facture/delete/<int:ID_Facture>/", views.FactureDeleteView.as_view(), name="WorkInApp_Facture_delete"),
    path("WorkInApp/Mission/", views.MissionListView.as_view(), name="WorkInApp_Mission_list"),
    path("WorkInApp/Mission/create/", views.MissionCreateView.as_view(), name="WorkInApp_Mission_create"),
    path("WorkInApp/Mission/detail/<int:ID_Mission>/", views.MissionDetailView.as_view(), name="WorkInApp_Mission_detail"),
    path("WorkInApp/Mission/update/<int:ID_Mission>/", views.MissionUpdateView.as_view(), name="WorkInApp_Mission_update"),
    path("WorkInApp/Mission/delete/<int:ID_Mission>/", views.MissionDeleteView.as_view(), name="WorkInApp_Mission_delete"),
    #path("WorkInApp/login/", views.loginn, name="WorkInApp_login"),
    #path("WorkInApp/register/", views.register, name="WorkInApp_register"),



)
